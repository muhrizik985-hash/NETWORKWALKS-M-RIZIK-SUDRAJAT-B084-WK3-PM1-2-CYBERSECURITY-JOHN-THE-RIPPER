# 🛡️ NetworkWalks Cybersecurity Internship - Week 3 Reports

Repositori ini berisi laporan praktikum resmi untuk **Week 3** dalam rangka program **NetworkWalks Cybersecurity & Ethical Hacking Internship**.

## 👨‍💻 Identitas Praktikan
* **Nama:** Muhammad Rizik Sudrajat
* **NIS:** 12511210
* **Kelas / Rayon:** TJKT XI-1 / Ciawi 2
* **Asal Instansi:** SMK Wikrama Bogor
* **Program:** Teknik Jaringan Komputer dan Telekomunikasi (TJKT)

---

## 📂 Struktur Repositori & Ringkasan Modul

### 1. [Modul 1: W3-PM1 (John the Ripper & Johnny GUI)](modul-1/Laporan_Praktikum_W3_PM1_Muhammad_Rizik_Sudrajat.pdf)
* **Topik:** Password Cracking pada dokumen PDF terenkripsi (`My Locked PDF1.pdf`) menggunakan John the Ripper (JTR) dan Johnny GUI di lingkungan Windows.
* **Tools Utama:** John the Ripper (1.9.0-jumbo-1), Johnny GUI v2.2, Online PDF Hash Extractor.
* **Hasil *Cracking*:** 
  * Password: `good-luck`
  * Flag: `nw{cybersecurity_flag_captured_2608}`

### 2. [Modul 2: W3-PM2 (Networkwalks Security Tools)](modul-2/Laporan_Praktikum_W3_PM2_Muhammad_Rizik_Sudrajat.pdf)
* **Topik:** Password Cracking dan ekstraksi hash menggunakan perangkat berbasis web NetworkWalks (*Hash Calculator* dan *Password Cracker*) dengan metode *Dictionary Attack*.
* **Tools Utama:** Networkwalks Hash Calculator & Networkwalks Password Cracker (Web-based tools).
* **Hasil *Cracking*:** 
  * Password: `password1` (ditemukan pada percobaan ke-91 dari 100 *built-in list*)
  * Flag: `nw{networkwalks_flag1_jtr_270521_1}`

---

## 🚀 Cara Upload ke GitHub

1. **Unduh & Ekstrak** file ZIP arsip repositori ini di komputer lokal Anda.
2. Buka [GitHub](https://github.com) dan buat repositori baru (misalnya beri nama `networkwalks-week3-reports`).
3. Anda dapat mengunggah file-file ini dengan dua cara:
   * **Melalui Web Browser:** Klik tombol `Add file` -> `Upload files`, lalu seret (*drag and drop*) seluruh isi folder `networkwalks-week3-reports` ke halaman web GitHub dan klik `Commit changes`.
   * **Melalui Git Terminal:**
     ```bash
     cd networkwalks-week3-reports
     git init
     git add .
     git commit -m "Initial commit: Week 3 cybersecurity practical reports"
     git branch -M main
     git remote add origin https://github.com/USERNAME/networkwalks-week3-reports.git
     git push -u origin main
     ```
4. Setelah ter-upload, Anda dapat membagikan tautan repositori GitHub Anda kepada instruktur atau penilai!
