# W3 – Password Cracking with John the Ripper & Networkwalks Tools

Pentesting Project Report | Networkwalks Cybersecurity Internship

**Author:** Muhammad Rizik Sudrajat
**Batch:** B084
**Week:** 03
**Date:** 16 November 2026

## 📄 Laporan

Laporan lengkap praktikum (langkah kerja, analisis, evidence screenshot, dan kesimpulan) tersedia di folder [`report/`](./report):

- **Project Module 1 (W3-PM1):** [`report/Laporan_W3_PM1_JohnTheRipper_JohnnyGUI.pdf`](./report/Laporan_W3_PM1_JohnTheRipper_JohnnyGUI.pdf)
- **Project Module 2 (W3-PM2):** [`report/Laporan_W3_PM2_NetworkwalksTools.pdf`](./report/Laporan_W3_PM2_NetworkwalksTools.pdf)

## 📦 Modules Completed

| Module | Topik | Tool | Target & Hasil |
|---|---|---|---|
| W3-PM1 | Password Cracking with John the Ripper (JTR) & Johnny GUI | John the Ripper `1.9.0-jumbo-1`, Johnny GUI `v2.2`, Online PDF Hash Extractor | `My Locked PDF1.pdf` → Password: `good-luck` (`nw{cybersecurity_flag_captured_2608}`) |
| W3-PM2 | Password Cracking with Networkwalks Tools | Networkwalks Hash Calculator & Password Cracker | `My-Locked-PDF1.pdf` → Password: `password1` (`nw{networkwalks_flag1_jtr_270521_1}`) |

## 📸 Screenshots

Seluruh tangkapan layar bukti pengerjaan praktikum diekstrak dan dikelompokkan di folder [`screenshots/`](./screenshots) berdasarkan modul:

- `screenshots/module1-jtr-johnny-gui/` — Unduh & konfigurasi John the Ripper (`john.exe`) di Johnny GUI, ekstraksi string `$pdf$...`, proses cracking hingga ditemukannya password `good-luck`, dan pembukaan file PDF target.
- `screenshots/module2-networkwalks-tools/` — Unduh file lab, ekstraksi PDF Hash lokal melalui Networkwalks Hash Calculator, dictionary attack (100 passwords) hingga ditemukannya password `password1` pada percobaan ke-91, serta verifikasi flag.

## ⚠️ Scope & Authorization

Seluruh aktivitas pada repositori ini dilakukan sesuai ketentuan Letter of Authorization dalam program **Networkwalks Cybersecurity & Ethical Hacking Internship**, dan hanya mencakup:
- Berkas target resmi latihan lab (`My Locked PDF1.pdf` / `My-Locked-PDF1.pdf`) yang disediakan pada portal lab NetworkWalks.
- Ekstraksi hash lokal serta pengujian *dictionary attack* offline untuk tujuan pembelajaran audit kekuatan kata sandi.

Materi ini murni untuk tujuan edukasi dan riset keamanan informasi. Tidak ada aktivitas serangan, brute-force, maupun akses tanpa izin terhadap sistem milik pihak ketiga.

## 📝 Catatan Teknis

- Pada **W3-PM1**, proses ekstraksi struktur enkripsi PDF (`$pdf$4*4*128*...`) memungkinkan John the Ripper melakukan pemulihan kata sandi secara offline dengan sangat cepat karena kata sandi yang digunakan (`good-luck`) termasuk frasa kamus umum.
- Pada **W3-PM2**, penggunaan kamus kecil berisi 100 kata sandi populer (*Built-in list*) sudah cukup untuk menembus proteksi dokumen (`password1` ditemukan pada percobaan ke-91), menunjukkan pentingnya penggunaan kata sandi yang panjang, acak, dan kompleks untuk melindungi dokumen sensitif.
