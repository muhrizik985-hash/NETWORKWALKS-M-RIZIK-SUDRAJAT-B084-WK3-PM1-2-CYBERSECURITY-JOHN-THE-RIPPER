# NetworkWalks Cybersecurity & Ethical Hacking Internship — Week 3 (PM1 & PM2)

Repositori dokumentasi praktikum **Password Cracking & Hash Extraction** pada program **NetworkWalks Cybersecurity & Ethical Hacking Internship (Batch B084)**.

- **Nama Praktikan:** Muhammad Rizik Sudrajat
- **Asal Instansi:** SMK Wikrama Bogor (XI TJKT-1)
- **Modul Tugas:** Week 3 — Project Module 1 (`W3-PM1`) & Project Module 2 (`W3-PM2`)

---

## Struktur Repositori

```text
NETWORKWALKS-W3-PM1-PM2-Password-Cracking/
├── Laporan/
│   ├── Laporan_Praktikum_W3-PM1_John_the_Ripper.pdf
│   └── Laporan_Praktikum_W3-PM2_Networkwalks_Tools.pdf
├── artifacts/
│   ├── w3_pm1_hash.txt
│   └── w3_pm2_hash.txt
└── README.md
```

---

## Ringkasan Praktikum

| Modul | Judul Praktikum | Tools yang Digunakan | Target File | Password Ditemukan | Flag |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **W3-PM1** | Password Cracking with John the Ripper (JTR) & Johnny GUI | John the Ripper `1.9.0-jumbo-1`, Johnny GUI `v2.2`, Online PDF Hash Extractor | `My Locked PDF1.pdf` | `good-luck` | `nw{cybersecurity_flag_captured_2608}` |
| **W3-PM2** | Password Cracking with Networkwalks Tools | Networkwalks Hash Calculator, Networkwalks Password Cracker | `My-Locked-PDF1.pdf` | `password1` | `nw{networkwalks_flag1_jtr_270521_1}` |

---

## Detail Eksekusi & Hasil

### 1. Project Module 1 (`W3-PM1`) — John the Ripper & Johnny GUI
- **Tujuan:** Melakukan ekstraksi hash dan pemulihan kata sandi pada berkas PDF terenkripsi (`My Locked PDF1.pdf`) di lingkungan Windows.
- **Alur Kerja:**
  1. Instalasi paket biner **John the Ripper 1.9.0-jumbo-1 (64-bit Windows)** dan **Johnny GUI v2.2**, lalu menghubungkan path `john.exe` pada menu *Settings*.
  2. Ekstraksi string hash format `$pdf$...` dari `My Locked PDF1.pdf` dan menyimpannya ke dalam `hash.txt`.
  3. Menjalankan serangan kata sandi otomatis melalui Johnny GUI (`Open password file (PASSWD format)` → `Start new attack`).
  4. Verifikasi akses dokumen dengan kata sandi `good-luck`.
- **Flag:** `nw{cybersecurity_flag_captured_2608}`

### 2. Project Module 2 (`W3-PM2`) — Networkwalks Web Tools
- **Tujuan:** Melakukan ekstraksi hash secara lokal di peramban dan menjalankan *dictionary attack* menggunakan perangkat berbasis web dari NetworkWalks.
- **Alur Kerja:**
  1. Mengunduh berkas target `My-Locked-PDF1.pdf` dari halaman lab NetworkWalks.
  2. Mengekstrak string hash `$pdf$...` (PDF Version 4, Revision 4, Key Length 128-bit) menggunakan **Networkwalks Hash Calculator**.
  3. Menjalankan *dictionary attack* pada **Networkwalks Password Cracker** menggunakan *built-in wordlist* (100 kata sandi umum) — kata sandi ditemukan pada percobaan ke-91.
  4. Verifikasi akses dokumen dengan kata sandi `password1`.
- **Flag:** `nw{networkwalks_flag1_jtr_270521_1}`

---

## Kesimpulan Keamanan
Kata sandi yang pendek, sederhana, atau terdaftar di dalam kamus kata sandi umum (*wordlist*) dapat dipulihkan dalam waktu singkat menggunakan alat audit keamanan maupun serangan berbasis kamus. Untuk melindungi kerahasiaan dokumen penting, gunakan kombinasi kata sandi panjang (minimal 12–16 karakter) yang mencakup huruf kapital, huruf kecil, angka, dan simbol acak.
